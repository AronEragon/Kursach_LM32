# README

This example blinks the green LED on the ST STM32F3DISCOVERY eval board.

When you press the 'USER' button, the blinking is slower.

